# ☕ Koffiebar Rush

Een snel browserspel waarin je je eigen koffiebar runt. Klanten komen bestellen, jij stelt de drankjes samen en je barista brengt ze naar de klant, voordat hun geduld op is!

## Spelen

Open `index.html` in je browser. Er is niets te installeren.

Of speel online via GitHub Pages (zie hieronder).

## Hoe werkt het?

- Klik op een **klant** om die te kiezen (of druk op `Tab`)
- Klik op **ingrediënten** om het kopje te vullen
- Druk op **Serveer** (`Spatie`): de barista loopt met het drankje naar de klant
- Ingrediënten raken **op**. Klik erop om bij te vullen, dat duurt even
- Sneller serveren levert meer fooi op 💰
- Laat je 3 klanten boos weglopen, dan gaat de zaak dicht

Elke dag komen er meer klanten, met minder geduld en nieuwe recepten.

## Sneltoetsen

| Toets | Actie |
|---|---|
| `1`–`9`, `0`, `Q`, `W`, `E`, `R` | Ingrediënt toevoegen |
| `Spatie` / `Enter` | Serveren |
| `Backspace` | Kopje weggooien |
| `Tab` | Volgende klant kiezen |
| `P` / `Esc` | Pauze |

## Inhoud

- 14 ingrediënten: espresso, melk, havermelk, melkschuim, heet water, thee, matcha, chocolade, karamel, vanille, hazelnoot, kaneel, ijsblokjes en slagroom
- 23 recepten, van Espresso tot Haver karamel latte
- Je record wordt in je browser bewaard

## Online zetten met GitHub Pages

1. Maak een nieuwe repository op GitHub en upload `index.html` en `README.md`
2. Ga naar **Settings → Pages**
3. Kies bij **Source**: *Deploy from a branch*, branch `main`, map `/ (root)`, en klik **Save**
4. Na een minuutje staat je spel op `https://<jouw-gebruikersnaam>.github.io/<repo-naam>/`

## Techniek

Eén HTML-bestand met gewone HTML, CSS en JavaScript. Er zijn geen libraries of build-stap nodig.
